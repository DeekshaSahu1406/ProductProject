package com.product.Request;


import lombok.Data;

@Data
public class ProductNameUpdateRequest {

    private Long id;

    private String name;
}
