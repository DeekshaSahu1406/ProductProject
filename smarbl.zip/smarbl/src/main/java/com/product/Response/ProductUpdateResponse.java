package com.product.Response;

public class ProductUpdateResponse {
}
